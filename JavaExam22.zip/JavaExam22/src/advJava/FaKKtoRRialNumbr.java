package advJava;

public class FaKKtoRRialNumbr {

    public static void main(String[]args){


        int a =1;
        int b= 7;
        for( int i=7;i>=1;i--){

            a= a*i;

            System.out.println(a);
        }









    }








}
